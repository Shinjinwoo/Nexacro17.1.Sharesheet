package com.example.androidruntime;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.sharesheet.MyService;
import com.nexacro.NexacroActivity;
import com.nexacro.NexacroResourceManager;
import com.tobesoft.plugin.sharesheet.PreferenceManager;
import com.tobesoft.plugin.sharesheet.SharesheetObject;
import com.tobesoft.plugin.sharesheet.plugininterface.SharesheetInterface;


public class NexacroActivityExt extends NexacroActivity implements SharesheetInterface {

    String mAppReceiveData = null;
    Intent mIntent = null;

    String LOG_TAG = this.getClass().getSimpleName();

    @Override
    public void onCreate(Bundle savedInstanceState)	{
        Log.e(LOG_TAG, "onCreate");
        mIntent = getIntent();
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
    }

    @Override
    protected void onPause() {
        PreferenceManager.clear(getApplicationContext());
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        PreferenceManager.clear(getApplicationContext());
        super.onDestroy();
    }


    /** Sharesheet 연동 코드 ****************************************************************************/

    private SharesheetObject mSharesheetObject;

    @Override
    public void setShresheetObject(SharesheetObject obj) {
        this.mSharesheetObject = obj;
    }

    @Override
    public String getShresheetData() {

        String sendText = PreferenceManager.getString(getApplicationContext(),"testKey");
        //String someText = intent.getStringExtra(Intent.EXTRA_TEXT);


        Log.e(LOG_TAG,sendText);

        return sendText;
    }
    /** Sharesheet 연동 코드 ****************************************************************************/

}

