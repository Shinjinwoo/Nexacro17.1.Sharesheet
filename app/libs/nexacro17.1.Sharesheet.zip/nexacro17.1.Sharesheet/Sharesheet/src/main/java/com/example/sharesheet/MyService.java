package com.example.sharesheet;

import android.app.Activity;
import android.app.NativeActivity;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.nexacro.NexacroActivity;
import com.tobesoft.plugin.sharesheet.plugininterface.SharesheetInterface;
import com.tobesoft.plugin.sharesheet.plugininterface.TestInterface;

import junit.framework.Test;

import static com.tobesoft.plugin.sharesheet.SharesheetObject.CODE_SUCCES;

public class MyService extends Service {


    private Activity mActivity = null;
    private SharesheetInterface mSharesheetInterface = null;
    private TestInterface mTestInterface = null;

    public MyService() {
        mSharesheetInterface = (SharesheetInterface)NexacroActivity.getInstance();
        mActivity = (Activity)NexacroActivity.getInstance();

        mTestInterface = (TestInterface)getApplicationContext();
        mTestInterface.setService(this);
    }

    @Override
    public void onCreate() {

        android.os.Debug.waitForDebugger();
        Log.e("StartService","onCreate()");
        super.onCreate();

        Log.e("서비스지로오오오옹","찍혀라아아아아아아ㅏㅇ");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        Log.e("서비스지로오오오옹","찍혀라아아아아아아ㅏㅇ");

        startActivity(intent);

        if (intent == null){
            return Service.START_STICKY;
        }
        else{
            String action = intent.getAction();
            String type = intent.getType();

            if(Intent.ACTION_SEND.equals(action)&& type != null) {

                if("text/plain".equals(type)) {
                    processCommand(intent);
                }else if (type.startsWith("image/")){
                    processCommand(intent);
                }
            }else if (Intent.ACTION_SEND_MULTIPLE.equals(action)&&type != null){
                if (type.startsWith("image/")){
                    processCommand(intent);
                } else {
                    return Service.START_STICKY;
                }
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }

    public void processCommand(Intent intent) {
        Intent intentForNexa = new Intent(getApplicationContext(),mActivity.getClass());
        intentForNexa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intentForNexa.putExtra("Sharesheet",intent);
        startActivity(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}