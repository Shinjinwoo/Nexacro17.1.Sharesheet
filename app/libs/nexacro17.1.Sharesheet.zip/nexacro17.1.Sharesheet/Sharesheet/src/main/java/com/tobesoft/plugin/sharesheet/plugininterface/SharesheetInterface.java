package com.tobesoft.plugin.sharesheet.plugininterface;

import com.example.sharesheet.MyService;
import com.tobesoft.plugin.sharesheet.SharesheetObject;

public interface SharesheetInterface {

    public void setShresheetObject(SharesheetObject obj);
    public String getShresheetData();

}
